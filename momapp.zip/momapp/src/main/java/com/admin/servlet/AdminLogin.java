package com.admin.servlet;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final String USERNAME = "admin@gmail.com";
    private static final String HASHED_PASSWORD = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918"; // Replace with the actual hashed password

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uname = request.getParameter("email");
        
        String password = request.getParameter("password");
        

        if (USERNAME.equals(uname) && verifyPassword(password, HASHED_PASSWORD)) {
        	
        	response.sendRedirect("admindash.jsp");
        } else {
        	
        	
            response.sendRedirect("admin_login.jsp?error=invalid");
        }
    }

    private boolean verifyPassword(String password, String hashedPassword) {
        try {
            String hashedInputPassword = hashPassword(password);
            
            return hashedInputPassword.equals(hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = md.digest(password.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedBytes) {
            sb.append(String.format("%02x", b));
        }
        
        return sb.toString();
    }
    

    public static void main(String[] args) throws NoSuchAlgorithmException {
        // Example usage to hash the password
        String password = "admin";
        AdminLogin al = new AdminLogin();
        System.out.println("Hashed password: " + al.hashPassword(password));
    }
}

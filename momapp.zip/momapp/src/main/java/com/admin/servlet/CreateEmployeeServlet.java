package com.admin.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.db.DBConnect;

@WebServlet({"/create_employee", "/delete_employee"})
public class CreateEmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("create".equals(action)) {
            // Handle employee creation
            createEmployee(request, response);
        } else if ("delete".equals(action)) {
            // Handle employee deletion
            deleteEmployee(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch and display the list of employees
        listEmployees(request, response);
    }

    private void createEmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String employeeId = request.getParameter("employee_id");
        String position = request.getParameter("position");
        String password = request.getParameter("password");

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DBConnect.getConnection();
            String insertSql = "INSERT INTO employees (name, employee_id, position, password) VALUES (?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(insertSql);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, employeeId);
            preparedStatement.setString(3, position);
            preparedStatement.setString(4, password);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                request.setAttribute("message", "Employee created successfully!");
                request.setAttribute("alertType", "success");
            } else {
                request.setAttribute("message", "Failed to create employee.");
                request.setAttribute("alertType", "danger");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("message", "Database error.");
            request.setAttribute("alertType", "danger");
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Redirect to GET method to show the form and employee list again
        listEmployees(request, response);
    }

    private void deleteEmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String employeeId = request.getParameter("employee_id");

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DBConnect.getConnection();
            String deleteSql = "DELETE FROM employees WHERE employee_id = ?";
            preparedStatement = connection.prepareStatement(deleteSql);
            preparedStatement.setString(1, employeeId);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                request.setAttribute("message", "Employee deleted successfully!");
                request.setAttribute("alertType", "success");
            } else {
                request.setAttribute("message", "Failed to delete employee.");
                request.setAttribute("alertType", "danger");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("message", "Database error.");
            request.setAttribute("alertType", "danger");
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Redirect to GET method to show the form and employee list again
        listEmployees(request, response);
    }

    private void listEmployees(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnect.getConnection();
            String selectSql = "SELECT name, employee_id, position, password FROM employees";
            preparedStatement = connection.prepareStatement(selectSql);
            resultSet = preparedStatement.executeQuery();

            List<String[]> employees = new ArrayList<>();
            while (resultSet.next()) {
                String[] emp = new String[4];
                emp[0] = resultSet.getString("name");
                emp[1] = resultSet.getString("employee_id");
                emp[2] = resultSet.getString("position");
                emp[3] = resultSet.getString("password"); // Be cautious with displaying passwords
                employees.add(emp);
            }

            request.setAttribute("employees", employees);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("message", "Database error.");
            request.setAttribute("alertType", "danger");
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        request.getRequestDispatcher("admindash.jsp").forward(request, response);
    }
}
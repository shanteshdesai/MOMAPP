package com.manager.dashboard.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.db.DBConnect;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ViewMeetingMinutesServlet")
public class ViewMeetingMinutesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String selectedMeetingId = request.getParameter("selectedMeetingId");

        Connection databaseConnection = null;
        PreparedStatement queryStatement = null;
        ResultSet resultSet = null;

        try {
            databaseConnection = DBConnect.getConnection();
            String selectMeetingDetailsSql = "SELECT * FROM meeting_minutes WHERE meeting_id = ?";
            queryStatement = databaseConnection.prepareStatement(selectMeetingDetailsSql);
            queryStatement.setString(1, selectedMeetingId);
            resultSet = queryStatement.executeQuery();

            if (resultSet.next()) {
                request.setAttribute("meetingId", resultSet.getString("meeting_id"));
                request.setAttribute("subject", resultSet.getString("subject"));
                request.setAttribute("purpose", resultSet.getString("purpose"));
                request.setAttribute("startDate", resultSet.getString("start_date"));
                request.setAttribute("startTime", resultSet.getString("start_time"));
                request.setAttribute("endDate", resultSet.getString("end_date"));
                request.setAttribute("endTime", resultSet.getString("end_time"));
                request.setAttribute("participantsPresent", resultSet.getString("participants_present"));
                request.setAttribute("participantsAbsent", resultSet.getString("participants_absent"));
                request.setAttribute("actionItems", resultSet.getString("action_items"));
            } else {
                request.setAttribute("error", "Meeting minutes not found.");
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
            request.setAttribute("error", "Error: " + sqlException.getMessage());
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (queryStatement != null) queryStatement.close();
                if (databaseConnection != null) databaseConnection.close();
            } catch (SQLException sqlException) {
                sqlException.printStackTrace();
            }
        }

        request.getRequestDispatcher("/viewMeetingMinutes.jsp").forward(request, response);
    }
}

package com.manager.dashboard.servlet;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.db.DBConnect;
@WebServlet("/ViewTaskStatusServlet")
public class ViewTaskStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String selectedTaskId = request.getParameter("taskIdSelector");
        if (selectedTaskId != null && !selectedTaskId.trim().isEmpty()) {
            try (Connection dbConnection = DBConnect.getConnection()) {
                String taskDetailsQuery = "SELECT t.task_id, t.task_description, e.name AS employee_name, t.status " +
                                          "FROM tasks t JOIN employees e ON t.employee_id = e.employee_id WHERE t.task_id = ?";
                try (PreparedStatement preparedStatement = dbConnection.prepareStatement(taskDetailsQuery)) {
                    preparedStatement.setString(1, selectedTaskId);
                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
                        if (resultSet.next()) {
                            request.setAttribute("taskId", resultSet.getString("task_id"));
                            request.setAttribute("taskDescription", resultSet.getString("task_description"));
                            request.setAttribute("employeeName", resultSet.getString("employee_name"));
                            request.setAttribute("taskStatus", resultSet.getString("status"));
                        } else {
                            request.setAttribute("error", "No task found with the provided ID.");
                        }
                    }
                }
            } catch (SQLException sqlException) {
                sqlException.printStackTrace();
                request.setAttribute("error", "Error fetching task details.");
            }
        } else {
            request.setAttribute("error", "Invalid Task ID.");
        }
        request.getRequestDispatcher("view_task_status.jsp").forward(request, response);
    }
}
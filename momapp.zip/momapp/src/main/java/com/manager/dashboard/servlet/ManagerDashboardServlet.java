package com.manager.dashboard.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.db.DBConnect;

@WebServlet("/ManagerDashboardServlet")
public class ManagerDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy");
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm");

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("Save Meeting Minutes".equals(action)) {
            saveMeetingMinutes(request, response);
        } else if ("Assign Task".equals(action)) {
            assignTask(request, response);
        }
    }

    private void saveMeetingMinutes(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String meetingId = request.getParameter("meetingId");
        String subject = request.getParameter("subject");
        String purpose = request.getParameter("purpose");

        String startDateStr = request.getParameter("startDate"); // Example: 01-09-2024
        String startTimeStr = request.getParameter("startTime"); // Example: 14:00
        String endDateStr = request.getParameter("endDate"); // Example: 01-09-2024
        String endTimeStr = request.getParameter("endTime"); // Example: 15:00

        // Convert strings to java.sql.Date and java.sql.Timestamp
        Date startDate = parseDate(startDateStr);
        Timestamp startTime = parseTimestamp(startDateStr, startTimeStr);
        Date endDate = parseDate(endDateStr);
        Timestamp endTime = parseTimestamp(endDateStr, endTimeStr);

        String participantsPresent = request.getParameter("participantsPresent");
        String participantsAbsent = request.getParameter("participantsAbsent");
        String actionItems = request.getParameter("actionItems");

        try (Connection conn = DBConnect.getConnection()) {
            String sql = "INSERT INTO meeting_minutes (meeting_id, subject, purpose, start_date, start_time, end_date, end_time, participants_present, participants_absent, action_items) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, meetingId);
                pstmt.setString(2, subject);
                pstmt.setString(3, purpose);
                pstmt.setDate(4, startDate); // Set as Date
                pstmt.setTimestamp(5, startTime); // Set as Timestamp
                pstmt.setDate(6, endDate); // Set as Date
                pstmt.setTimestamp(7, endTime); // Set as Timestamp
                pstmt.setString(8, participantsPresent);
                pstmt.setString(9, participantsAbsent);
                pstmt.setString(10, actionItems);

                pstmt.executeUpdate();
                request.setAttribute("message", "Meeting minutes saved successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Error saving meeting minutes.");
        }
        request.getRequestDispatcher("managerdash.jsp").forward(request, response);
    }

    private Date parseDate(String dateStr) throws ServletException {
        try {
            java.util.Date date = DATE_FORMAT.parse(dateStr);
            return new Date(date.getTime());
        } catch (ParseException e) {
            throw new ServletException("Date format is incorrect. Expected format is dd-MM-yyyy", e);
        }
    }

    private Timestamp parseTimestamp(String dateStr, String timeStr) throws ServletException {
        try {
            java.util.Date date = DATE_FORMAT.parse(dateStr);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            String datetimeStr = dateStr + " " + timeStr;
            java.util.Date datetime = new SimpleDateFormat("dd-MM-yyyy HH:mm").parse(datetimeStr);
            calendar.setTime(datetime);
            return new Timestamp(calendar.getTimeInMillis());
        } catch (ParseException e) {
            throw new ServletException("Datetime format is incorrect. Expected format is dd-MM-yyyy HH:mm", e);
        }
    }

    private void assignTask(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String taskId = request.getParameter("taskId");
        String taskDescription = request.getParameter("taskDescription");
        String employeeId = request.getParameter("employee");

        try (Connection conn = DBConnect.getConnection()) {
            String sql = "INSERT INTO tasks (task_id, task_description, employee_id) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, taskId);
                pstmt.setString(2, taskDescription);
                pstmt.setString(3, employeeId);

                pstmt.executeUpdate();
                request.setAttribute("message", "Task assigned successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Error assigning task.");
        }
        request.getRequestDispatcher("managerdash.jsp").forward(request, response);
    }
}

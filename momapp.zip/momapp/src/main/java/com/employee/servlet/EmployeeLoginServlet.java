package com.employee.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.db.DBConnect;

@WebServlet("/employee_login")
public class EmployeeLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String employeeId = request.getParameter("id");
        String password = request.getParameter("password");
        String position = request.getParameter("role");

        HttpSession session = request.getSession();
        boolean isValidUser = false;

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM employees WHERE employee_id = ? AND position = ? AND password = ?")) {
            
            stmt.setString(1, employeeId);
            stmt.setString(2, position);
            stmt.setString(3, password);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    isValidUser = true;
                    // Set the session attribute consistently
                    session.setAttribute("employee_id", employeeId);
                    session.setAttribute("position", position);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Consider using a logging framework
        }

        if (isValidUser) {
            if ("manager".equals(position)) {
                response.sendRedirect("managerdash.jsp?message=loginSuccess");
            } else if ("employee".equals(position)) {
                response.sendRedirect("employeedash.jsp?message=loginSuccess");
            }
        } else {
            response.sendRedirect("employee_login.jsp?error=InvalidCredentials");
        }
    }
}

package com.employee.dashboard.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.db.DBConnect;

@WebServlet("/updateTaskStatus")
public class UpdateTaskStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String taskId = request.getParameter("task_id");
        String status = request.getParameter("status");
        String message = null;
        String error = null;

        if (taskId != null && status != null) {
            Connection conn = null;
            PreparedStatement pstmt = null;
            try {
                conn = DBConnect.getConnection();
                String sql = "UPDATE tasks SET status = ? WHERE task_id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, status);
                pstmt.setString(2, taskId);
                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
                    message = "Task status updated successfully.";
                } else {
                    error = "Failed to update task status.";
                }
            } catch (SQLException e) {
                error = "SQL Exception: " + e.getMessage();
                e.printStackTrace();
            } finally {
                try {
                    if (pstmt != null) pstmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    error = "SQL Exception in finally block: " + e.getMessage();
                    e.printStackTrace();
                }
            }
        } else {
            error = "Invalid Task ID or Status.";
        }

        // Redirect back to the update task page with message or error
        response.sendRedirect("update_task.jsp?task_id=" + taskId + 
                             (message != null ? "&message=" + java.net.URLEncoder.encode(message, "ISO-8859-1") : "") +
                             (error != null ? "&error=" + java.net.URLEncoder.encode(error, "ISO-8859-1") : ""));
    }
}
